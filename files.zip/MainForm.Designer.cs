namespace DriveMate;

partial class MainForm
{
    private System.ComponentModel.IContainer? components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        pnlTop = new Panel(); lblWho = new Label(); btnAccount = new Button(); btnLogout = new Button();
        tabs = new TabControl();
        tabBrowse = new TabPage(); tabTrips = new TabPage(); tabMyCars = new TabPage(); tabRequests = new TabPage();
        // browse
        gridBrowse = new DataGridView(); pnlBrowseBtns = new FlowLayoutPanel(); btnBook = new Button();
        pnlFilter = new Panel(); lblCity = new Label(); cboCity = new ComboBox(); lblGear = new Label(); cboGear = new ComboBox();
        lblMax = new Label(); nudMax = new NumericUpDown(); btnSearch = new Button();
        // trips
        gridTrips = new DataGridView(); pnlTripBtns = new FlowLayoutPanel();
        btnPay = new Button(); btnCancelTrip = new Button(); btnTripReport = new Button(); btnTripPhotos = new Button(); btnRate = new Button();
        // my cars
        gridMyCars = new DataGridView(); pnlCarBtns = new FlowLayoutPanel();
        btnAddCar = new Button(); btnEditCar = new Button(); btnPause = new Button(); btnRemoveCar = new Button();
        // requests
        gridReqs = new DataGridView(); pnlReqBtns = new FlowLayoutPanel(); lblEarnings = new Label();
        btnApprove = new Button(); btnDecline = new Button(); btnStart = new Button(); btnEnd = new Button();
        btnReqReport = new Button(); btnReqPhotos = new Button();
        ((System.ComponentModel.ISupportInitialize)gridBrowse).BeginInit();
        ((System.ComponentModel.ISupportInitialize)gridTrips).BeginInit();
        ((System.ComponentModel.ISupportInitialize)gridMyCars).BeginInit();
        ((System.ComponentModel.ISupportInitialize)gridReqs).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nudMax).BeginInit();
        SuspendLayout();

        // top bar
        pnlTop.BackColor = Color.FromArgb(24, 90, 157); pnlTop.Dock = DockStyle.Top; pnlTop.Height = 44;
        pnlTop.Controls.Add(lblWho); pnlTop.Controls.Add(btnAccount); pnlTop.Controls.Add(btnLogout);
        lblWho.Dock = DockStyle.Left; lblWho.Width = 600; lblWho.ForeColor = Color.White;
        lblWho.Font = new Font("Segoe UI", 11F, FontStyle.Bold); lblWho.TextAlign = ContentAlignment.MiddleLeft;
        btnAccount.Dock = DockStyle.Right; btnAccount.Width = 110; btnAccount.Text = "My account";
        btnAccount.FlatStyle = FlatStyle.Flat; btnAccount.ForeColor = Color.White; btnAccount.Click += btnAccount_Click;
        btnLogout.Dock = DockStyle.Right; btnLogout.Width = 90; btnLogout.Text = "Logout";
        btnLogout.FlatStyle = FlatStyle.Flat; btnLogout.ForeColor = Color.White; btnLogout.Click += btnLogout_Click;

        // browse tab
        gridBrowse.Dock = DockStyle.Fill;
        pnlBrowseBtns.Dock = DockStyle.Bottom; pnlBrowseBtns.Height = 46; pnlBrowseBtns.Padding = new Padding(4);
        pnlBrowseBtns.Controls.Add(btnBook);
        btnBook.AutoSize = true; btnBook.Text = "Request to book"; btnBook.Click += btnBook_Click;
        pnlFilter.Dock = DockStyle.Top; pnlFilter.Height = 44;
        lblCity.AutoSize = true; lblCity.Location = new Point(8, 14); lblCity.Text = "City";
        cboCity.DropDownStyle = ComboBoxStyle.DropDownList; cboCity.Location = new Point(48, 10); cboCity.Size = new Size(130, 28);
        lblGear.AutoSize = true; lblGear.Location = new Point(195, 14); lblGear.Text = "Gearbox";
        cboGear.DropDownStyle = ComboBoxStyle.DropDownList; cboGear.Items.AddRange(new object[] { "Any", "Automatic", "Manual" });
        cboGear.Location = new Point(255, 10); cboGear.Size = new Size(110, 28);
        lblMax.AutoSize = true; lblMax.Location = new Point(385, 14); lblMax.Text = "Max ₱/day";
        nudMax.Location = new Point(455, 10); nudMax.Size = new Size(95, 27);
        nudMax.Minimum = 500; nudMax.Maximum = 100000; nudMax.Increment = 100; nudMax.Value = 100000;
        btnSearch.Location = new Point(570, 8); btnSearch.Size = new Size(90, 30); btnSearch.Text = "Search"; btnSearch.Click += btnSearch_Click;
        pnlFilter.Controls.AddRange(new Control[] { lblCity, cboCity, lblGear, cboGear, lblMax, nudMax, btnSearch });
        tabBrowse.Text = "Browse cars"; tabBrowse.Padding = new Padding(3);
        tabBrowse.Controls.Add(gridBrowse); tabBrowse.Controls.Add(pnlBrowseBtns); tabBrowse.Controls.Add(pnlFilter);

        // my trips tab
        gridTrips.Dock = DockStyle.Fill;
        pnlTripBtns.Dock = DockStyle.Bottom; pnlTripBtns.Height = 46; pnlTripBtns.Padding = new Padding(4);
        pnlTripBtns.Controls.AddRange(new Control[] { btnPay, btnCancelTrip, btnTripReport, btnTripPhotos, btnRate });
        btnPay.AutoSize = true; btnPay.Text = "Pay now (GCash / Maya / Card)"; btnPay.Click += btnPay_Click;
        btnCancelTrip.AutoSize = true; btnCancelTrip.Text = "Cancel booking"; btnCancelTrip.Click += btnCancelTrip_Click;
        btnTripReport.AutoSize = true; btnTripReport.Text = "Inspection report"; btnTripReport.Click += btnTripReport_Click;
        btnTripPhotos.AutoSize = true; btnTripPhotos.Text = "View photos"; btnTripPhotos.Click += btnPhotos_Click;
        btnRate.AutoSize = true; btnRate.Text = "Rate trip"; btnRate.Click += btnRate_Click;
        tabTrips.Text = "My trips"; tabTrips.Padding = new Padding(3);
        tabTrips.Controls.Add(gridTrips); tabTrips.Controls.Add(pnlTripBtns);

        // my cars tab
        gridMyCars.Dock = DockStyle.Fill;
        pnlCarBtns.Dock = DockStyle.Bottom; pnlCarBtns.Height = 46; pnlCarBtns.Padding = new Padding(4);
        pnlCarBtns.Controls.AddRange(new Control[] { btnAddCar, btnEditCar, btnPause, btnRemoveCar });
        btnAddCar.AutoSize = true; btnAddCar.Text = "List a car"; btnAddCar.Click += btnAddCar_Click;
        btnEditCar.AutoSize = true; btnEditCar.Text = "Edit"; btnEditCar.Click += btnEditCar_Click;
        btnPause.AutoSize = true; btnPause.Text = "Pause / resume listing"; btnPause.Click += btnPause_Click;
        btnRemoveCar.AutoSize = true; btnRemoveCar.Text = "Remove"; btnRemoveCar.Click += btnRemoveCar_Click;
        tabMyCars.Text = "My cars"; tabMyCars.Padding = new Padding(3);
        tabMyCars.Controls.Add(gridMyCars); tabMyCars.Controls.Add(pnlCarBtns);

        // booking requests tab
        gridReqs.Dock = DockStyle.Fill;
        pnlReqBtns.Dock = DockStyle.Bottom; pnlReqBtns.Height = 80; pnlReqBtns.Padding = new Padding(4);
        pnlReqBtns.Controls.AddRange(new Control[] { btnApprove, btnDecline, btnStart, btnEnd, btnReqReport, btnReqPhotos });
        btnApprove.AutoSize = true; btnApprove.Text = "Approve"; btnApprove.Click += btnApprove_Click;
        btnDecline.AutoSize = true; btnDecline.Text = "Decline"; btnDecline.Click += btnDecline_Click;
        btnStart.AutoSize = true; btnStart.Text = "Start trip (pickup inspection)"; btnStart.Click += btnStart_Click;
        btnEnd.AutoSize = true; btnEnd.Text = "End trip (return inspection)"; btnEnd.Click += btnEnd_Click;
        btnReqReport.AutoSize = true; btnReqReport.Text = "Inspection report"; btnReqReport.Click += btnReqReport_Click;
        btnReqPhotos.AutoSize = true; btnReqPhotos.Text = "View photos"; btnReqPhotos.Click += btnPhotos_Click;
        lblEarnings.Dock = DockStyle.Top; lblEarnings.Height = 30; lblEarnings.Padding = new Padding(8, 0, 0, 0);
        lblEarnings.Font = new Font("Segoe UI", 10F, FontStyle.Bold); lblEarnings.TextAlign = ContentAlignment.MiddleLeft;
        tabRequests.Text = "Booking requests"; tabRequests.Padding = new Padding(3);
        tabRequests.Controls.Add(gridReqs); tabRequests.Controls.Add(pnlReqBtns); tabRequests.Controls.Add(lblEarnings);

        tabs.Dock = DockStyle.Fill;
        tabs.TabPages.AddRange(new TabPage[] { tabBrowse, tabTrips, tabMyCars, tabRequests });

        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1060, 600);
        StartPosition = FormStartPosition.CenterScreen; Text = "DriveMate";
        Controls.Add(tabs); Controls.Add(pnlTop);
        ((System.ComponentModel.ISupportInitialize)gridBrowse).EndInit();
        ((System.ComponentModel.ISupportInitialize)gridTrips).EndInit();
        ((System.ComponentModel.ISupportInitialize)gridMyCars).EndInit();
        ((System.ComponentModel.ISupportInitialize)gridReqs).EndInit();
        ((System.ComponentModel.ISupportInitialize)nudMax).EndInit();
        ResumeLayout(false);
    }

    private Panel pnlTop, pnlFilter;
    private Label lblWho, lblCity, lblGear, lblMax, lblEarnings;
    private Button btnAccount, btnLogout, btnBook, btnSearch, btnPay, btnCancelTrip, btnTripReport, btnTripPhotos, btnRate,
        btnAddCar, btnEditCar, btnPause, btnRemoveCar, btnApprove, btnDecline, btnStart, btnEnd, btnReqReport, btnReqPhotos;
    private TabControl tabs;
    private TabPage tabBrowse, tabTrips, tabMyCars, tabRequests;
    private DataGridView gridBrowse, gridTrips, gridMyCars, gridReqs;
    private FlowLayoutPanel pnlBrowseBtns, pnlTripBtns, pnlCarBtns, pnlReqBtns;
    private ComboBox cboCity, cboGear;
    private NumericUpDown nudMax;
}
