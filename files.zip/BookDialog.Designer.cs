namespace DriveMate;

partial class BookDialog
{
    private System.ComponentModel.IContainer? components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblCarCaption = new Label(); lblCar = new Label(); lblStart = new Label(); lblEnd = new Label(); lblSummaryCaption = new Label();
        lblSummary = new Label(); dtpStart = new DateTimePicker(); dtpEnd = new DateTimePicker();
        btnSend = new Button(); btnCancel = new Button();
        SuspendLayout();
        lblCarCaption.AutoSize = true; lblCarCaption.Location = new Point(20, 22); lblCarCaption.Text = "Car";
        lblCar.AutoSize = true; lblCar.Location = new Point(150, 22); lblCar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        lblStart.AutoSize = true; lblStart.Location = new Point(20, 64); lblStart.Text = "Pick-up date";
        lblEnd.AutoSize = true; lblEnd.Location = new Point(20, 104); lblEnd.Text = "Return date";
        lblSummaryCaption.AutoSize = true; lblSummaryCaption.Location = new Point(20, 148); lblSummaryCaption.Text = "Summary";
        lblSummary.Location = new Point(150, 148); lblSummary.Size = new Size(240, 50);
        dtpStart.Format = DateTimePickerFormat.Short; dtpStart.Location = new Point(150, 60); dtpStart.Size = new Size(160, 27);
        dtpStart.ValueChanged += dtp_ValueChanged;
        dtpEnd.Format = DateTimePickerFormat.Short; dtpEnd.Location = new Point(150, 100); dtpEnd.Size = new Size(160, 27);
        dtpEnd.ValueChanged += dtp_ValueChanged;
        btnSend.Location = new Point(150, 215); btnSend.Size = new Size(130, 34); btnSend.Text = "Send request";
        btnSend.Click += btnSend_Click;
        btnCancel.DialogResult = DialogResult.Cancel;
        btnCancel.Location = new Point(290, 215); btnCancel.Size = new Size(95, 34); btnCancel.Text = "Cancel";
        AcceptButton = btnSend; CancelButton = btnCancel;
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(410, 270);
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent; Text = "Request to book";
        Controls.AddRange(new Control[] { lblCarCaption, lblCar, lblStart, lblEnd, lblSummaryCaption, lblSummary, dtpStart, dtpEnd, btnSend, btnCancel });
        ResumeLayout(false); PerformLayout();
    }

    private Label lblCarCaption, lblCar, lblStart, lblEnd, lblSummaryCaption, lblSummary;
    private DateTimePicker dtpStart, dtpEnd;
    private Button btnSend, btnCancel;
}
