using System.Security.Cryptography;

namespace DriveMate;

public enum Role { Renter, Host }
public enum BookingStatus { Pending, Approved, Declined, Cancelled, Active, Completed }

public class User
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public Role Role { get; set; }
}

public class Car
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid HostId { get; set; }
    public string Make { get; set; } = "";
    public string Model { get; set; } = "";
    public int Year { get; set; }
    public string Plate { get; set; } = "";
    public string Transmission { get; set; } = "Automatic";
    public int Seats { get; set; } = 5;
    public string Location { get; set; } = "Manila";
    public decimal PricePerDay { get; set; }
    public decimal Deposit { get; set; }
    public bool Available { get; set; } = true;
    public string HostName { get; set; } = "";
    public double AvgRating { get; set; }
    public int RatingCount { get; set; }
    public override string ToString() => $"{Year} {Make} {Model}";
}

public class PhotoItem
{
    public string FileName { get; set; } = "";
    public byte[] Data { get; set; } = Array.Empty<byte>();
}

/// <summary>Digital check-in / check-out record with photo evidence.</summary>
public class Inspection
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid BookingId { get; set; }
    public string Stage { get; set; } = "Pickup";
    public int Odometer { get; set; }
    public int FuelPercent { get; set; } = 100;
    public bool Scratches { get; set; }
    public bool InteriorDirty { get; set; }
    public bool TireOrLightIssue { get; set; }
    public string Notes { get; set; } = "";
    public DateTime At { get; set; } = DateTime.Now;
    public int PhotoCount { get; set; }
    public List<PhotoItem> NewPhotos { get; set; } = new();   // not loaded from DB; used when saving
}

public class Booking
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid CarId { get; set; }
    public Guid RenterId { get; set; }
    public Guid HostId { get; set; }
    public DateTime Start { get; set; }
    public DateTime End { get; set; }
    public BookingStatus Status { get; set; } = BookingStatus.Pending;
    public decimal Total { get; set; }
    public decimal Deposit { get; set; }
    public decimal Deductions { get; set; }
    public decimal Refund { get; set; }
    public int Rating { get; set; }
    public string Review { get; set; } = "";
    public string PaymentMethod { get; set; } = "";
    public string PaymentRef { get; set; } = "";
    public DateTime? PaidAt { get; set; }
    public string RefundRef { get; set; } = "";
    public string CarName { get; set; } = "";
    public string OtherName { get; set; } = "";
    public Inspection? Pickup { get; set; }
    public Inspection? Return { get; set; }
    public int Days => Math.Max(1, (End.Date - Start.Date).Days);
    public decimal AmountDue => Total + Deposit;
    public bool IsPaid => PaidAt != null;
}

/// <summary>
/// Smart Inspection &amp; Auto-Deposit Settlement: compares pickup vs return inspections
/// and computes deposit deductions automatically.
/// </summary>
public static class Charges
{
    public const decimal FuelPerPercent = 15m;
    public const decimal ExtraKm = 12m;
    public const int FreeKmPerDay = 200;
    public const decimal Scratch = 1500m, Interior = 500m, Tire = 1000m;

    public static (List<string> Lines, decimal Total) Compute(Booking b)
    {
        var lines = new List<string>();
        decimal t = 0;
        if (b.Pickup is null || b.Return is null) return (lines, 0);

        int fuel = b.Pickup.FuelPercent - b.Return.FuelPercent;
        if (fuel > 0) { var a = fuel * FuelPerPercent; t += a; lines.Add($"Fuel shortfall ({fuel}%): ₱{a:N0}"); }

        int extra = (b.Return.Odometer - b.Pickup.Odometer) - FreeKmPerDay * b.Days;
        if (extra > 0) { var a = extra * ExtraKm; t += a; lines.Add($"Excess mileage ({extra} km): ₱{a:N0}"); }

        if (b.Return.Scratches && !b.Pickup.Scratches) { t += Scratch; lines.Add($"New scratches/dents: ₱{Scratch:N0}"); }
        if (b.Return.InteriorDirty && !b.Pickup.InteriorDirty) { t += Interior; lines.Add($"Interior cleaning: ₱{Interior:N0}"); }
        if (b.Return.TireOrLightIssue && !b.Pickup.TireOrLightIssue) { t += Tire; lines.Add($"Tire/light issue: ₱{Tire:N0}"); }

        return (lines, Math.Min(t, b.Deposit));
    }
}

/// <summary>Salted PBKDF2 password hashing (stored as "salt.hash", both Base64).</summary>
public static class Security
{
    const int Iterations = 100_000;

    public static string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var h = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);
        return Convert.ToBase64String(salt) + "." + Convert.ToBase64String(h);
    }

    public static bool Verify(string password, string stored)
    {
        var p = stored.Split('.');
        if (p.Length != 2) return false;
        var h = Rfc2898DeriveBytes.Pbkdf2(password, Convert.FromBase64String(p[0]), Iterations, HashAlgorithmName.SHA256, 32);
        return CryptographicOperations.FixedTimeEquals(h, Convert.FromBase64String(p[1]));
    }
}
