using System.Text.RegularExpressions;

namespace DriveMate;

/// <summary>Swap SimulatedGateway for a real PayMongo / GCash / Maya integration later.</summary>
public interface IPaymentGateway
{
    (bool ok, string reference, string message) Charge(string method, string account, decimal amount);
    string Refund(string method, string originalReference, decimal amount);
}

public class SimulatedGateway : IPaymentGateway
{
    public static readonly string[] Methods = { "GCash", "Maya", "Credit/Debit Card" };
    static readonly Random Rng = new();

    public (bool ok, string reference, string message) Charge(string method, string account, decimal amount)
    {
        if (amount <= 0) return (false, "", "Invalid amount.");
        if (method.StartsWith("Credit"))
        {
            var digits = new string(account.Where(char.IsDigit).ToArray());
            if (digits.Length != 16) return (false, "", "Enter a valid 16-digit card number.");
        }
        else if (!Regex.IsMatch(account.Trim(), @"^09\d{9}$"))
            return (false, "", $"Enter a valid {method} mobile number (09XXXXXXXXX).");

        var prefix = method == "GCash" ? "GC" : method == "Maya" ? "MY" : "CD";
        return (true, $"{prefix}-{Rng.NextInt64(1_000_000_000, 9_999_999_999)}", "Approved");
    }

    public string Refund(string method, string originalReference, decimal amount)
        => $"RF-{Rng.NextInt64(1_000_000_000, 9_999_999_999)}";
}

public static class Pay
{
    public static IPaymentGateway Gateway { get; set; } = new SimulatedGateway();
}
