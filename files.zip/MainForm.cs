using System.Text;

namespace DriveMate;

record CarRow(string Car, string Gearbox, int Seats, string Location, string PerDay, string Deposit, string Host, string Rating, string Listed);
record TripRow(string Car, string With, string From, string To, int Days, string Total, string Status, string Paid, string Refund, string Review);

public partial class MainForm : Form
{
    readonly User me;
    public bool LoggedOut;
    List<Car> browseCars = new(), myCars = new();
    List<Booking> trips = new(), reqs = new();

    public MainForm(User u)
    {
        InitializeComponent();
        me = u;
        UpdateHeader();
        foreach (var g in new[] { gridBrowse, gridTrips, gridMyCars, gridReqs }) Ui.StyleGrid(g);

        if (me.Role == Role.Renter)
        {
            tabs.TabPages.Remove(tabMyCars); tabs.TabPages.Remove(tabRequests);
            cboCity.Items.Add("All"); cboCity.Items.AddRange(Ui.Cities); cboCity.SelectedIndex = 0; cboGear.SelectedIndex = 0;
            LoadCars(); LoadTrips();
        }
        else
        {
            tabs.TabPages.Remove(tabBrowse); tabs.TabPages.Remove(tabTrips);
            LoadMyCars(); LoadReqs();
        }
    }

    // ---------- helpers ----------
    void UpdateHeader() => lblWho.Text = $"  🚗 DriveMate   ·   {me.FullName} ({me.Role})";

    T? Sel<T>(DataGridView g, List<T> list) where T : class
    {
        int i = g.CurrentRow?.Index ?? -1;
        if (i < 0 || i >= list.Count) { Ui.Info("Please select a row first."); return null; }
        return list[i];
    }

    static CarRow ToRow(Car c, bool host) => new(c.ToString(), c.Transmission, c.Seats, c.Location,
        c.PricePerDay.ToString("₱#,##0"), c.Deposit.ToString("₱#,##0"), host ? "—" : c.HostName,
        c.RatingCount == 0 ? "New" : $"★ {c.AvgRating:0.0} ({c.RatingCount})", c.Available ? "Yes" : "Paused");

    static TripRow ToRow(Booking b) => new(b.CarName, b.OtherName, b.Start.ToString("MMM d"), b.End.ToString("MMM d"),
        b.Days, b.Total.ToString("₱#,##0"), b.Status.ToString(), b.IsPaid ? $"Yes ({b.PaymentMethod})" : "No",
        b.Status is BookingStatus.Completed or BookingStatus.Cancelled && b.Refund > 0 ? b.Refund.ToString("₱#,##0") : "—",
        b.Rating > 0 ? new string('★', b.Rating) : "");

    static string YN(bool v) => v ? "yes" : "no";

    static string Report(Booking b)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"{b.CarName}  ({b.Start:MMM d} – {b.End:MMM d})\n");
        if (b.IsPaid) sb.AppendLine($"PAID    ₱{b.AmountDue:N0} via {b.PaymentMethod} (ref {b.PaymentRef})");
        if (b.Pickup != null)
            sb.AppendLine($"PICKUP  {b.Pickup.Odometer:N0} km · fuel {b.Pickup.FuelPercent}% · scratches {YN(b.Pickup.Scratches)} · dirty {YN(b.Pickup.InteriorDirty)} · tire/light {YN(b.Pickup.TireOrLightIssue)} · {b.Pickup.PhotoCount} photo(s)");
        if (b.Return != null)
            sb.AppendLine($"RETURN  {b.Return.Odometer:N0} km · fuel {b.Return.FuelPercent}% · scratches {YN(b.Return.Scratches)} · dirty {YN(b.Return.InteriorDirty)} · tire/light {YN(b.Return.TireOrLightIssue)} · {b.Return.PhotoCount} photo(s)");
        if (b.Pickup == null) sb.AppendLine("No inspection recorded yet.");
        if (b.Status == BookingStatus.Completed)
        {
            var (lines, total) = Charges.Compute(b);
            sb.AppendLine("\nDeposit settlement:");
            if (lines.Count == 0) sb.AppendLine("  No deductions 🎉");
            foreach (var l in lines) sb.AppendLine("  • " + l);
            sb.AppendLine($"\nDeposit ₱{b.Deposit:N0} − deductions ₱{total:N0} = REFUND ₱{b.Refund:N0}" +
                          (b.RefundRef != "" ? $" (ref {b.RefundRef})" : ""));
        }
        return sb.ToString();
    }

    private void btnAccount_Click(object? sender, EventArgs e)
    {
        using var f = new AccountForm(me);
        f.ShowDialog(this);
        UpdateHeader();
        if (me.Role == Role.Renter) LoadCars(); else LoadMyCars();
    }

    private void btnLogout_Click(object? sender, EventArgs e) { LoggedOut = true; Close(); }

    private void btnPhotos_Click(object? sender, EventArgs e)
    {
        var b = me.Role == Role.Renter ? Sel(gridTrips, trips) : Sel(gridReqs, reqs);
        if (b == null) return;
        if (b.Pickup == null && b.Return == null) { Ui.Info("No inspection has been recorded for this booking yet."); return; }
        using var f = new PhotoViewerForm(b);
        f.ShowDialog(this);
    }

    // ---------- renter ----------
    void LoadCars()
    {
        browseCars = Database.SearchCars(cboCity.Text, cboGear.Text, nudMax.Value);
        gridBrowse.DataSource = browseCars.Select(c => ToRow(c, false)).ToList();
    }

    void LoadTrips()
    {
        trips = Database.BookingsForRenter(me.Id);
        gridTrips.DataSource = trips.Select(b => ToRow(b)).ToList();
    }

    private void btnSearch_Click(object? sender, EventArgs e) => LoadCars();

    private void btnBook_Click(object? sender, EventArgs e)
    {
        var car = Sel(gridBrowse, browseCars);
        if (car == null) return;
        using var d = new BookDialog(car);
        if (d.ShowDialog(this) == DialogResult.OK && d.Result != null)
        {
            d.Result.RenterId = me.Id;
            Database.AddBooking(d.Result);
            LoadTrips();
            Ui.Info("Request sent! Once the host approves, use 'Pay now' in My trips.");
        }
    }

    private void btnPay_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridTrips, trips);
        if (b == null) return;
        if (b.IsPaid) { Ui.Info("This booking is already paid."); return; }
        if (b.Status != BookingStatus.Approved) { Ui.Info("You can pay once the host has approved your request."); return; }
        using var d = new PaymentDialog(b.AmountDue);
        if (d.ShowDialog(this) != DialogResult.OK) return;
        b.PaymentMethod = d.Method; b.PaymentRef = d.Reference; b.PaidAt = DateTime.Now;
        Database.SaveBooking(b); LoadTrips();
        Ui.Info($"Payment received.\nReference: {b.PaymentRef}");
    }

    private void btnCancelTrip_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridTrips, trips);
        if (b == null) return;
        if (b.Status != BookingStatus.Pending && b.Status != BookingStatus.Approved) { Ui.Info("Only pending or approved bookings can be cancelled."); return; }
        if (!Ui.Ask("Cancel this booking?" + (b.IsPaid ? "\nYour payment will be refunded in full." : ""))) return;
        if (b.IsPaid) { b.RefundRef = Pay.Gateway.Refund(b.PaymentMethod, b.PaymentRef, b.AmountDue); b.Refund = b.AmountDue; }
        b.Status = BookingStatus.Cancelled;
        Database.SaveBooking(b); LoadTrips();
    }

    private void btnTripReport_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridTrips, trips);
        if (b != null) Ui.Info(Report(b));
    }

    private void btnRate_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridTrips, trips);
        if (b == null) return;
        if (b.Status != BookingStatus.Completed || b.Rating > 0) { Ui.Info("You can rate a completed trip once."); return; }
        using var d = new ReviewDialog();
        if (d.ShowDialog(this) == DialogResult.OK) { b.Rating = d.Rating; b.Review = d.Comment; Database.SaveBooking(b); LoadTrips(); }
    }

    // ---------- host ----------
    void LoadMyCars()
    {
        myCars = Database.CarsByHost(me.Id);
        gridMyCars.DataSource = myCars.Select(c => ToRow(c, true)).ToList();
    }

    void LoadReqs()
    {
        reqs = Database.BookingsForHost(me.Id);
        gridReqs.DataSource = reqs.Select(b => ToRow(b)).ToList();
        var done = reqs.Where(b => b.Status == BookingStatus.Completed).Sum(b => b.Total + b.Deductions);
        var upcoming = reqs.Where(b => b.Status is BookingStatus.Approved or BookingStatus.Active).Sum(b => b.Total);
        lblEarnings.Text = $"Earned: ₱{done:N0}    Upcoming: ₱{upcoming:N0}    Pending requests: {reqs.Count(b => b.Status == BookingStatus.Pending)}";
    }

    void EditCar(Car? c)
    {
        using var d = new CarDialog(c, me.Id);
        if (d.ShowDialog(this) != DialogResult.OK) return;
        Database.SaveCar(d.Result); LoadMyCars();
    }

    private void btnAddCar_Click(object? sender, EventArgs e) => EditCar(null);

    private void btnEditCar_Click(object? sender, EventArgs e)
    {
        var c = Sel(gridMyCars, myCars);
        if (c != null) EditCar(c);
    }

    private void btnPause_Click(object? sender, EventArgs e)
    {
        var c = Sel(gridMyCars, myCars);
        if (c == null) return;
        c.Available = !c.Available; Database.SaveCar(c); LoadMyCars();
    }

    private void btnRemoveCar_Click(object? sender, EventArgs e)
    {
        var c = Sel(gridMyCars, myCars);
        if (c == null || !Ui.Ask($"Remove {c}?")) return;
        if (!Database.DeleteCar(c.Id)) Ui.Info("This car has booking history and can't be deleted. Use 'Pause / resume listing' instead.");
        LoadMyCars();
    }

    void Decide(bool approve)
    {
        var b = Sel(gridReqs, reqs);
        if (b == null) return;
        if (b.Status != BookingStatus.Pending) { Ui.Info("Only pending requests can be approved or declined."); return; }
        if (approve && Database.HasClash(b.CarId, b.Start, b.End, b.Id)) { Ui.Info("Those dates now overlap with another approved booking."); return; }
        b.Status = approve ? BookingStatus.Approved : BookingStatus.Declined;
        Database.SaveBooking(b); LoadReqs();
    }

    private void btnApprove_Click(object? sender, EventArgs e) => Decide(true);
    private void btnDecline_Click(object? sender, EventArgs e) => Decide(false);

    private void btnStart_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridReqs, reqs);
        if (b == null) return;
        if (b.Status != BookingStatus.Approved) { Ui.Info("Only approved bookings can be started."); return; }
        if (!b.IsPaid) { Ui.Info("The renter hasn't paid yet. Hand over the car only after payment is received."); return; }
        using var d = new InspectionDialog("Pickup", b);
        if (d.ShowDialog(this) != DialogResult.OK) return;
        Database.SaveInspection(d.Result);
        b.Status = BookingStatus.Active; Database.SaveBooking(b); LoadReqs();
    }

    private void btnEnd_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridReqs, reqs);
        if (b == null) return;
        if (b.Status != BookingStatus.Active || b.Pickup == null) { Ui.Info("Only active trips can be ended."); return; }
        using var d = new InspectionDialog("Return", b);
        if (d.ShowDialog(this) != DialogResult.OK) return;

        Database.SaveInspection(d.Result);
        b.Return = d.Result;
        var (_, total) = Charges.Compute(b);
        b.Deductions = total; b.Refund = b.Deposit - total;
        if (b.Refund > 0) b.RefundRef = Pay.Gateway.Refund(b.PaymentMethod, b.PaymentRef, b.Refund);
        b.Status = BookingStatus.Completed;
        Database.SaveBooking(b); LoadReqs();
        Ui.Info("Trip completed.\n\n" + Report(b));
    }

    private void btnReqReport_Click(object? sender, EventArgs e)
    {
        var b = Sel(gridReqs, reqs);
        if (b != null) Ui.Info(Report(b));
    }
}
