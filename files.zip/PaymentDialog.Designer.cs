namespace DriveMate;

partial class PaymentDialog
{
    private System.ComponentModel.IContainer? components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblAmount = new Label(); lblMethod = new Label(); lblAccount = new Label(); lblNote = new Label();
        cboMethod = new ComboBox(); txtAccount = new TextBox(); btnPay = new Button(); btnCancel = new Button();
        SuspendLayout();
        lblAmount.Font = new Font("Segoe UI", 11F, FontStyle.Bold); lblAmount.Location = new Point(20, 18); lblAmount.Size = new Size(360, 50);
        lblMethod.AutoSize = true; lblMethod.Location = new Point(20, 86); lblMethod.Text = "Pay with";
        cboMethod.DropDownStyle = ComboBoxStyle.DropDownList; cboMethod.Location = new Point(150, 82); cboMethod.Size = new Size(220, 28);
        cboMethod.SelectedIndexChanged += cboMethod_SelectedIndexChanged;
        lblAccount.AutoSize = true; lblAccount.Location = new Point(20, 126); lblAccount.Text = "Account";
        txtAccount.Location = new Point(150, 122); txtAccount.Size = new Size(220, 27);
        lblNote.Font = new Font("Segoe UI", 8.5F, FontStyle.Italic); lblNote.ForeColor = Color.DimGray;
        lblNote.Location = new Point(20, 165); lblNote.Size = new Size(350, 45);
        lblNote.Text = "Demo mode: payment is simulated through IPaymentGateway. No real money moves.";
        btnPay.Location = new Point(150, 230); btnPay.Size = new Size(130, 34); btnPay.Text = "Pay now"; btnPay.Click += btnPay_Click;
        btnCancel.DialogResult = DialogResult.Cancel; btnCancel.Location = new Point(290, 230); btnCancel.Size = new Size(80, 34); btnCancel.Text = "Cancel";
        AcceptButton = btnPay; CancelButton = btnCancel;
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(395, 285);
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent; Text = "Pay for booking";
        Controls.AddRange(new Control[] { lblAmount, lblMethod, cboMethod, lblAccount, txtAccount, lblNote, btnPay, btnCancel });
        ResumeLayout(false); PerformLayout();
    }

    private Label lblAmount, lblMethod, lblAccount, lblNote;
    private ComboBox cboMethod;
    private TextBox txtAccount;
    private Button btnPay, btnCancel;
}
