namespace DriveMate;

public partial class AccountForm : Form
{
    readonly User me;

    public AccountForm(User user)
    {
        InitializeComponent();
        me = user;
        txtName.Text = me.FullName; txtEmail.Text = me.Email; lblRoleValue.Text = me.Role.ToString();
    }

    private void btnSaveProfile_Click(object? sender, EventArgs e)
    {
        var name = txtName.Text.Trim();
        var mail = txtEmail.Text.Trim().ToLowerInvariant();
        if (name.Length < 2) { Ui.Info("Please enter your full name."); return; }
        if (!mail.Contains('@') || !mail.Contains('.')) { Ui.Info("Please enter a valid email address."); return; }
        if (Database.EmailTaken(mail, me.Id)) { Ui.Info("That email is already used by another account."); return; }

        Database.UpdateProfile(me.Id, name, mail);
        me.FullName = name; me.Email = mail;
        Ui.Info("Profile updated.");
    }

    private void btnChangePw_Click(object? sender, EventArgs e)
    {
        if (!Security.Verify(txtCur.Text, me.PasswordHash)) { Ui.Info("Your current password is incorrect."); return; }
        if (txtNew.Text.Length < 6) { Ui.Info("The new password must be at least 6 characters."); return; }
        if (txtNew.Text != txtConf.Text) { Ui.Info("The new password and confirmation do not match."); return; }

        var hash = Security.Hash(txtNew.Text);
        Database.UpdatePassword(me.Id, hash);
        me.PasswordHash = hash;
        txtCur.Clear(); txtNew.Clear(); txtConf.Clear();
        Ui.Info("Password changed.");
    }
}
