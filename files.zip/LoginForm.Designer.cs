namespace DriveMate;

partial class LoginForm
{
    private System.ComponentModel.IContainer? components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label(); lblEmail = new Label(); lblPass = new Label(); lblName = new Label(); lblRole = new Label();
        txtEmail = new TextBox(); txtPass = new TextBox(); txtName = new TextBox(); cboRole = new ComboBox();
        btnLogin = new Button(); btnRegister = new Button();
        SuspendLayout();
        // lblTitle
        lblTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
        lblTitle.Location = new Point(0, 10); lblTitle.Size = new Size(400, 55);
        lblTitle.Text = "🚗 DriveMate"; lblTitle.TextAlign = ContentAlignment.MiddleCenter;
        // labels
        lblEmail.AutoSize = true; lblEmail.Location = new Point(30, 84); lblEmail.Text = "Email";
        lblPass.AutoSize = true; lblPass.Location = new Point(30, 119); lblPass.Text = "Password";
        lblName.AutoSize = true; lblName.Location = new Point(30, 154); lblName.Text = "Full name (register)";
        lblRole.AutoSize = true; lblRole.Location = new Point(30, 189); lblRole.Text = "Register as";
        // inputs
        txtEmail.Location = new Point(170, 80); txtEmail.Size = new Size(200, 27);
        txtPass.Location = new Point(170, 115); txtPass.Size = new Size(200, 27); txtPass.UseSystemPasswordChar = true;
        txtName.Location = new Point(170, 150); txtName.Size = new Size(200, 27);
        cboRole.DropDownStyle = ComboBoxStyle.DropDownList; cboRole.Items.AddRange(new object[] { "Renter", "Host" });
        cboRole.Location = new Point(170, 185); cboRole.Size = new Size(200, 28);
        // buttons
        btnLogin.Location = new Point(170, 240); btnLogin.Size = new Size(95, 34); btnLogin.Text = "Login";
        btnLogin.Click += btnLogin_Click;
        btnRegister.Location = new Point(275, 240); btnRegister.Size = new Size(95, 34); btnRegister.Text = "Register";
        btnRegister.Click += btnRegister_Click;
        // form
        AcceptButton = btnLogin;
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(400, 310);
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen; Text = "DriveMate – Sign in";
        Controls.AddRange(new Control[] { lblTitle, lblEmail, lblPass, lblName, lblRole, txtEmail, txtPass, txtName, cboRole, btnLogin, btnRegister });
        ResumeLayout(false); PerformLayout();
    }

    private Label lblTitle, lblEmail, lblPass, lblName, lblRole;
    private TextBox txtEmail, txtPass, txtName;
    private ComboBox cboRole;
    private Button btnLogin, btnRegister;
}
