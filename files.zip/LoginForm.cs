namespace DriveMate;

public partial class LoginForm : Form
{
    public User? User { get; private set; }

    public LoginForm()
    {
        InitializeComponent();
        cboRole.SelectedIndex = 0;
    }

    private void btnLogin_Click(object? sender, EventArgs e)
    {
        var u = Database.GetUserByEmail(txtEmail.Text.Trim());
        if (u is null || !Security.Verify(txtPass.Text, u.PasswordHash))
        { Ui.Info("Invalid email or password.\nDemo: host@demo.com or renter@demo.com / demo123"); return; }
        User = u;
        DialogResult = DialogResult.OK;
    }

    private void btnRegister_Click(object? sender, EventArgs e)
    {
        var mail = txtEmail.Text.Trim().ToLowerInvariant();
        if (txtName.Text.Trim().Length < 2 || !mail.Contains('@') || txtPass.Text.Length < 6)
        { Ui.Info("Enter your full name, a valid email, and a password of at least 6 characters."); return; }
        if (Database.EmailTaken(mail, Guid.Empty)) { Ui.Info("That email is already registered."); return; }

        var u = new User
        {
            FullName = txtName.Text.Trim(), Email = mail, PasswordHash = Security.Hash(txtPass.Text),
            Role = cboRole.SelectedIndex == 1 ? Role.Host : Role.Renter
        };
        Database.AddUser(u);
        User = u;
        DialogResult = DialogResult.OK;
    }
}
