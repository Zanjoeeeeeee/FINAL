namespace DriveMate;

public partial class BookDialog : Form
{
    public Booking? Result { get; private set; }
    readonly Car car;

    public BookDialog(Car car)
    {
        InitializeComponent();
        this.car = car;
        lblCar.Text = $"{car}  ·  {car.Location}";
        dtpStart.MinDate = DateTime.Today; dtpEnd.MinDate = DateTime.Today;
        dtpStart.Value = DateTime.Today.AddDays(1); dtpEnd.Value = DateTime.Today.AddDays(3);
        Recalc();
    }

    int Days => (dtpEnd.Value.Date - dtpStart.Value.Date).Days;

    void Recalc() => lblSummary.Text = Days < 1
        ? "Return must be after pick-up."
        : $"{Days} day(s) × ₱{car.PricePerDay:N0} = ₱{Days * car.PricePerDay:N0}\nRefundable deposit: ₱{car.Deposit:N0}";

    private void dtp_ValueChanged(object? sender, EventArgs e) => Recalc();

    private void btnSend_Click(object? sender, EventArgs e)
    {
        if (Days < 1) { Ui.Info("Return date must be after pick-up date."); return; }
        if (Database.HasClash(car.Id, dtpStart.Value, dtpEnd.Value, Guid.Empty))
        { Ui.Info("This car is already booked for those dates."); return; }

        Result = new Booking
        {
            CarId = car.Id, HostId = car.HostId, Start = dtpStart.Value.Date, End = dtpEnd.Value.Date,
            Total = Days * car.PricePerDay, Deposit = car.Deposit
        };
        DialogResult = DialogResult.OK;
    }
}
