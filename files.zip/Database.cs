using Microsoft.Data.SqlClient;

namespace DriveMate;

/// <summary>
/// SQL Server data layer. The database and tables are created automatically on first run.
/// View it in Visual Studio: View > SQL Server Object Explorer > (localdb)\MSSQLLocalDB > Databases > DriveMate.
/// </summary>
public static class Database
{
    // Change for SQL Server Express (@".\SQLEXPRESS") or a full instance (@"MYPC\MSSQLSERVER01").
    public const string Server = @"(localdb)\MSSQLLocalDB";
    const string DbName = "DriveMate";

    static string Cs(string db) =>
        $"Server={Server};Database={db};Integrated Security=true;TrustServerCertificate=True;Encrypt=False;";

    // ---------- plumbing ----------
    static SqlConnection Open(string db = DbName) { var c = new SqlConnection(Cs(db)); c.Open(); return c; }

    static SqlCommand Cmd(SqlConnection c, string sql, (string n, object? v)[] p, SqlTransaction? tx = null)
    {
        var cmd = c.CreateCommand();
        cmd.CommandText = sql; cmd.Transaction = tx;
        foreach (var (n, v) in p) cmd.Parameters.AddWithValue(n, v ?? DBNull.Value);
        return cmd;
    }

    static int Exec(string sql, params (string n, object? v)[] p)
    { using var c = Open(); using var cmd = Cmd(c, sql, p); return cmd.ExecuteNonQuery(); }

    static int Count(string sql, params (string n, object? v)[] p)
    { using var c = Open(); using var cmd = Cmd(c, sql, p); return (int)cmd.ExecuteScalar()!; }

    static List<T> Query<T>(string sql, Func<SqlDataReader, T> map, params (string n, object? v)[] p)
    {
        using var c = Open(); using var cmd = Cmd(c, sql, p); using var r = cmd.ExecuteReader();
        var list = new List<T>();
        while (r.Read()) list.Add(map(r));
        return list;
    }

    // ---------- schema ----------
    const string Schema = @"
IF OBJECT_ID('dbo.Users','U') IS NULL CREATE TABLE dbo.Users(
  Id UNIQUEIDENTIFIER PRIMARY KEY, FullName NVARCHAR(100) NOT NULL, Email NVARCHAR(150) NOT NULL UNIQUE,
  PasswordHash NVARCHAR(200) NOT NULL, [Role] INT NOT NULL);

IF OBJECT_ID('dbo.Cars','U') IS NULL CREATE TABLE dbo.Cars(
  Id UNIQUEIDENTIFIER PRIMARY KEY, HostId UNIQUEIDENTIFIER NOT NULL REFERENCES dbo.Users(Id),
  Make NVARCHAR(50) NOT NULL, Model NVARCHAR(50) NOT NULL, [Year] INT NOT NULL, Plate NVARCHAR(20) NOT NULL,
  Transmission NVARCHAR(20) NOT NULL, Seats INT NOT NULL, Location NVARCHAR(60) NOT NULL,
  PricePerDay DECIMAL(10,2) NOT NULL, Deposit DECIMAL(10,2) NOT NULL, Available BIT NOT NULL DEFAULT 1);

IF OBJECT_ID('dbo.Bookings','U') IS NULL CREATE TABLE dbo.Bookings(
  Id UNIQUEIDENTIFIER PRIMARY KEY,
  CarId UNIQUEIDENTIFIER NOT NULL REFERENCES dbo.Cars(Id),
  RenterId UNIQUEIDENTIFIER NOT NULL REFERENCES dbo.Users(Id),
  HostId UNIQUEIDENTIFIER NOT NULL REFERENCES dbo.Users(Id),
  StartDate DATE NOT NULL, EndDate DATE NOT NULL, [Status] INT NOT NULL,
  Total DECIMAL(10,2) NOT NULL, Deposit DECIMAL(10,2) NOT NULL,
  Deductions DECIMAL(10,2) NOT NULL DEFAULT 0, Refund DECIMAL(10,2) NOT NULL DEFAULT 0,
  Rating INT NOT NULL DEFAULT 0, Review NVARCHAR(500) NOT NULL DEFAULT '',
  PaymentMethod NVARCHAR(30) NOT NULL DEFAULT '', PaymentRef NVARCHAR(40) NOT NULL DEFAULT '',
  PaidAt DATETIME2 NULL, RefundRef NVARCHAR(40) NOT NULL DEFAULT '');

IF OBJECT_ID('dbo.Inspections','U') IS NULL CREATE TABLE dbo.Inspections(
  Id UNIQUEIDENTIFIER PRIMARY KEY,
  BookingId UNIQUEIDENTIFIER NOT NULL REFERENCES dbo.Bookings(Id) ON DELETE CASCADE,
  Stage NVARCHAR(10) NOT NULL, Odometer INT NOT NULL, FuelPercent INT NOT NULL,
  Scratches BIT NOT NULL, InteriorDirty BIT NOT NULL, TireOrLightIssue BIT NOT NULL,
  Notes NVARCHAR(500) NOT NULL, TakenAt DATETIME2 NOT NULL);

IF OBJECT_ID('dbo.InspectionPhotos','U') IS NULL CREATE TABLE dbo.InspectionPhotos(
  Id UNIQUEIDENTIFIER PRIMARY KEY,
  InspectionId UNIQUEIDENTIFIER NOT NULL REFERENCES dbo.Inspections(Id) ON DELETE CASCADE,
  FileName NVARCHAR(200) NOT NULL, Photo VARBINARY(MAX) NOT NULL);";

    public static void Init()
    {
        using (var c = Open("master"))
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = $"IF DB_ID('{DbName}') IS NULL CREATE DATABASE [{DbName}]";
            cmd.ExecuteNonQuery();
        }
        Exec(Schema);
        if (Count("SELECT COUNT(*) FROM dbo.Users") == 0) Seed();
    }

    static void Seed()
    {
        var host = new User { FullName = "Maria Host", Email = "host@demo.com", PasswordHash = Security.Hash("demo123"), Role = Role.Host };
        var renter = new User { FullName = "Juan Renter", Email = "renter@demo.com", PasswordHash = Security.Hash("demo123"), Role = Role.Renter };
        AddUser(host); AddUser(renter);
        SaveCar(new Car { HostId = host.Id, Make = "Toyota", Model = "Vios", Year = 2022, Plate = "ABC 1234", Seats = 5, Location = "Makati", PricePerDay = 1800, Deposit = 3000 });
        SaveCar(new Car { HostId = host.Id, Make = "Mitsubishi", Model = "Xpander", Year = 2023, Plate = "XYZ 5678", Seats = 7, Location = "Quezon City", PricePerDay = 2800, Deposit = 5000 });
    }

    // ---------- users ----------
    static User MapUser(SqlDataReader r) => new()
    {
        Id = (Guid)r["Id"], FullName = (string)r["FullName"], Email = (string)r["Email"],
        PasswordHash = (string)r["PasswordHash"], Role = (Role)(int)r["Role"]
    };

    public static User? GetUserByEmail(string email) =>
        Query<User>("SELECT * FROM dbo.Users WHERE Email=@e", MapUser, ("@e", email)).FirstOrDefault();

    public static bool EmailTaken(string email, Guid exceptId) =>
        Count("SELECT COUNT(*) FROM dbo.Users WHERE Email=@e AND Id<>@x", ("@e", email), ("@x", exceptId)) > 0;

    public static void AddUser(User u) => Exec(
        "INSERT INTO dbo.Users(Id,FullName,Email,PasswordHash,[Role]) VALUES(@i,@n,@e,@p,@r)",
        ("@i", u.Id), ("@n", u.FullName), ("@e", u.Email), ("@p", u.PasswordHash), ("@r", (int)u.Role));

    public static void UpdateProfile(Guid id, string name, string email) =>
        Exec("UPDATE dbo.Users SET FullName=@n, Email=@e WHERE Id=@i", ("@n", name), ("@e", email), ("@i", id));

    public static void UpdatePassword(Guid id, string hash) =>
        Exec("UPDATE dbo.Users SET PasswordHash=@p WHERE Id=@i", ("@p", hash), ("@i", id));

    // ---------- cars ----------
    const string CarSelect = @"SELECT c.*, u.FullName AS HostName, ISNULL(r.AvgR,0) AS AvgR, ISNULL(r.Cnt,0) AS Cnt
FROM dbo.Cars c JOIN dbo.Users u ON u.Id=c.HostId
LEFT JOIN (SELECT CarId, AVG(CAST(Rating AS FLOAT)) AS AvgR, COUNT(*) AS Cnt FROM dbo.Bookings WHERE Rating>0 GROUP BY CarId) r ON r.CarId=c.Id ";

    static Car MapCar(SqlDataReader r) => new()
    {
        Id = (Guid)r["Id"], HostId = (Guid)r["HostId"], Make = (string)r["Make"], Model = (string)r["Model"],
        Year = (int)r["Year"], Plate = (string)r["Plate"], Transmission = (string)r["Transmission"],
        Seats = (int)r["Seats"], Location = (string)r["Location"], PricePerDay = (decimal)r["PricePerDay"],
        Deposit = (decimal)r["Deposit"], Available = (bool)r["Available"], HostName = (string)r["HostName"],
        AvgRating = (double)r["AvgR"], RatingCount = (int)r["Cnt"]
    };

    public static List<Car> SearchCars(string city, string gear, decimal maxPrice) => Query<Car>(
        CarSelect + "WHERE c.Available=1 AND c.PricePerDay<=@m AND (@city='All' OR c.Location=@city) AND (@gear='Any' OR c.Transmission=@gear) ORDER BY c.PricePerDay",
        MapCar, ("@m", maxPrice), ("@city", city), ("@gear", gear));

    public static List<Car> CarsByHost(Guid hostId) =>
        Query<Car>(CarSelect + "WHERE c.HostId=@h ORDER BY c.Make, c.Model", MapCar, ("@h", hostId));

    public static void SaveCar(Car c) => Exec(@"
IF EXISTS(SELECT 1 FROM dbo.Cars WHERE Id=@Id)
  UPDATE dbo.Cars SET Make=@Make, Model=@Model, [Year]=@Year, Plate=@Plate, Transmission=@Trans, Seats=@Seats,
         Location=@Loc, PricePerDay=@Price, Deposit=@Dep, Available=@Avail WHERE Id=@Id
ELSE
  INSERT INTO dbo.Cars(Id,HostId,Make,Model,[Year],Plate,Transmission,Seats,Location,PricePerDay,Deposit,Available)
  VALUES(@Id,@HostId,@Make,@Model,@Year,@Plate,@Trans,@Seats,@Loc,@Price,@Dep,@Avail)",
        ("@Id", c.Id), ("@HostId", c.HostId), ("@Make", c.Make), ("@Model", c.Model), ("@Year", c.Year),
        ("@Plate", c.Plate), ("@Trans", c.Transmission), ("@Seats", c.Seats), ("@Loc", c.Location),
        ("@Price", c.PricePerDay), ("@Dep", c.Deposit), ("@Avail", c.Available));

    /// <summary>Returns false when the car has booking history (pause the listing instead).</summary>
    public static bool DeleteCar(Guid id)
    {
        if (Count("SELECT COUNT(*) FROM dbo.Bookings WHERE CarId=@i", ("@i", id)) > 0) return false;
        Exec("DELETE FROM dbo.Cars WHERE Id=@i", ("@i", id));
        return true;
    }

    // ---------- bookings ----------
    const string BookingSelect = @"SELECT b.*, CAST(c.[Year] AS NVARCHAR(4))+' '+c.Make+' '+c.Model AS CarName, u.FullName AS OtherName
FROM dbo.Bookings b JOIN dbo.Cars c ON c.Id=b.CarId JOIN dbo.Users u ON u.Id=";

    static Booking MapBooking(SqlDataReader r) => new()
    {
        Id = (Guid)r["Id"], CarId = (Guid)r["CarId"], RenterId = (Guid)r["RenterId"], HostId = (Guid)r["HostId"],
        Start = (DateTime)r["StartDate"], End = (DateTime)r["EndDate"], Status = (BookingStatus)(int)r["Status"],
        Total = (decimal)r["Total"], Deposit = (decimal)r["Deposit"], Deductions = (decimal)r["Deductions"],
        Refund = (decimal)r["Refund"], Rating = (int)r["Rating"], Review = (string)r["Review"],
        PaymentMethod = (string)r["PaymentMethod"], PaymentRef = (string)r["PaymentRef"],
        PaidAt = r["PaidAt"] as DateTime?, RefundRef = (string)r["RefundRef"],
        CarName = (string)r["CarName"], OtherName = (string)r["OtherName"]
    };

    static Inspection MapInspection(SqlDataReader r) => new()
    {
        Id = (Guid)r["Id"], BookingId = (Guid)r["BookingId"], Stage = (string)r["Stage"],
        Odometer = (int)r["Odometer"], FuelPercent = (int)r["FuelPercent"], Scratches = (bool)r["Scratches"],
        InteriorDirty = (bool)r["InteriorDirty"], TireOrLightIssue = (bool)r["TireOrLightIssue"],
        Notes = (string)r["Notes"], At = (DateTime)r["TakenAt"], PhotoCount = (int)r["PhotoCount"]
    };

    static List<Booking> AttachInspections(List<Booking> list)
    {
        foreach (var b in list)
            foreach (var i in Query<Inspection>(
                @"SELECT i.*, (SELECT COUNT(*) FROM dbo.InspectionPhotos p WHERE p.InspectionId=i.Id) AS PhotoCount
                  FROM dbo.Inspections i WHERE i.BookingId=@b", MapInspection, ("@b", b.Id)))
            {
                if (i.Stage == "Pickup") b.Pickup = i; else b.Return = i;
            }
        return list;
    }

    public static List<Booking> BookingsForRenter(Guid renterId) => AttachInspections(Query<Booking>(
        BookingSelect + "b.HostId WHERE b.RenterId=@id ORDER BY b.StartDate DESC", MapBooking, ("@id", renterId)));

    public static List<Booking> BookingsForHost(Guid hostId) => AttachInspections(Query<Booking>(
        BookingSelect + "b.RenterId WHERE b.HostId=@id ORDER BY b.StartDate DESC", MapBooking, ("@id", hostId)));

    public static bool HasClash(Guid carId, DateTime start, DateTime end, Guid exceptBookingId) => Count(
        $@"SELECT COUNT(*) FROM dbo.Bookings WHERE CarId=@c AND Id<>@x
           AND [Status] IN ({(int)BookingStatus.Approved},{(int)BookingStatus.Active})
           AND @s < EndDate AND @e > StartDate",
        ("@c", carId), ("@x", exceptBookingId), ("@s", start.Date), ("@e", end.Date)) > 0;

    public static void AddBooking(Booking b) => Exec(
        @"INSERT INTO dbo.Bookings(Id,CarId,RenterId,HostId,StartDate,EndDate,[Status],Total,Deposit)
          VALUES(@i,@c,@r,@h,@s,@e,@st,@t,@d)",
        ("@i", b.Id), ("@c", b.CarId), ("@r", b.RenterId), ("@h", b.HostId), ("@s", b.Start.Date),
        ("@e", b.End.Date), ("@st", (int)b.Status), ("@t", b.Total), ("@d", b.Deposit));

    public static void SaveBooking(Booking b) => Exec(
        @"UPDATE dbo.Bookings SET [Status]=@st, Deductions=@dd, Refund=@rf, Rating=@ra, Review=@rv,
          PaymentMethod=@pm, PaymentRef=@pr, PaidAt=@pa, RefundRef=@rr WHERE Id=@i",
        ("@st", (int)b.Status), ("@dd", b.Deductions), ("@rf", b.Refund), ("@ra", b.Rating), ("@rv", b.Review),
        ("@pm", b.PaymentMethod), ("@pr", b.PaymentRef), ("@pa", b.PaidAt), ("@rr", b.RefundRef), ("@i", b.Id));

    // ---------- inspections & photos ----------
    public static void SaveInspection(Inspection i)
    {
        using var c = Open();
        using var tx = c.BeginTransaction();
        using (var cmd = Cmd(c, @"INSERT INTO dbo.Inspections(Id,BookingId,Stage,Odometer,FuelPercent,Scratches,InteriorDirty,TireOrLightIssue,Notes,TakenAt)
                                  VALUES(@i,@b,@s,@o,@f,@sc,@d,@t,@n,@a)",
            new (string, object?)[] { ("@i", i.Id), ("@b", i.BookingId), ("@s", i.Stage), ("@o", i.Odometer), ("@f", i.FuelPercent),
                ("@sc", i.Scratches), ("@d", i.InteriorDirty), ("@t", i.TireOrLightIssue), ("@n", i.Notes), ("@a", i.At) }, tx))
            cmd.ExecuteNonQuery();

        foreach (var p in i.NewPhotos)
            using (var cmd = Cmd(c, "INSERT INTO dbo.InspectionPhotos(Id,InspectionId,FileName,Photo) VALUES(NEWID(),@i,@n,@d)",
                new (string, object?)[] { ("@i", i.Id), ("@n", p.FileName), ("@d", p.Data) }, tx))
                cmd.ExecuteNonQuery();

        tx.Commit();
        i.PhotoCount = i.NewPhotos.Count;
    }

    public static List<PhotoItem> GetPhotos(Guid inspectionId) => Query<PhotoItem>(
        "SELECT FileName, Photo FROM dbo.InspectionPhotos WHERE InspectionId=@i",
        r => new PhotoItem { FileName = (string)r["FileName"], Data = (byte[])r["Photo"] }, ("@i", inspectionId));
}
