namespace DriveMate;

public partial class CarDialog : Form
{
    public Car Result { get; private set; }

    public CarDialog(Car? existing, Guid hostId)
    {
        InitializeComponent();
        nudYear.Maximum = DateTime.Now.Year + 1;
        cboLoc.Items.AddRange(Ui.Cities);
        Result = existing ?? new Car { HostId = hostId };

        if (existing != null)
        {
            Text = "Edit car";
            txtMake.Text = existing.Make; txtModel.Text = existing.Model; txtPlate.Text = existing.Plate;
            nudYear.Value = existing.Year; nudSeats.Value = existing.Seats;
            nudPrice.Value = existing.PricePerDay; nudDeposit.Value = existing.Deposit;
            cboTrans.Text = existing.Transmission; cboLoc.Text = existing.Location;
        }
        else { cboTrans.SelectedIndex = 0; cboLoc.SelectedIndex = 0; }
    }

    private void btnSave_Click(object? sender, EventArgs e)
    {
        if (txtMake.Text.Trim() == "" || txtModel.Text.Trim() == "" || txtPlate.Text.Trim() == "" || cboLoc.Text.Trim() == "")
        { Ui.Info("Please fill in make, model, plate and city."); return; }

        Result.Make = txtMake.Text.Trim(); Result.Model = txtModel.Text.Trim();
        Result.Plate = txtPlate.Text.Trim().ToUpper();
        Result.Year = (int)nudYear.Value; Result.Seats = (int)nudSeats.Value;
        Result.Transmission = cboTrans.Text; Result.Location = cboLoc.Text.Trim();
        Result.PricePerDay = nudPrice.Value; Result.Deposit = nudDeposit.Value;
        DialogResult = DialogResult.OK;
    }
}
