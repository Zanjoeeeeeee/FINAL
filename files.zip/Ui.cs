namespace DriveMate;

public static class Ui
{
    public static readonly string[] Cities =
        { "Manila", "Makati", "Quezon City", "Taguig", "Pasig", "Cebu", "Davao", "Baguio", "Clark" };

    public static void Info(string m) => MessageBox.Show(m, "DriveMate", MessageBoxButtons.OK, MessageBoxIcon.Information);
    public static bool Ask(string m) => MessageBox.Show(m, "DriveMate", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;

    public static void StyleGrid(DataGridView g)
    {
        g.ReadOnly = true; g.AllowUserToAddRows = false; g.AllowUserToDeleteRows = false;
        g.SelectionMode = DataGridViewSelectionMode.FullRowSelect; g.MultiSelect = false;
        g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; g.RowHeadersVisible = false;
        g.BackgroundColor = Color.White;
    }
}
