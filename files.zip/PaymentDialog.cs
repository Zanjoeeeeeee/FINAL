namespace DriveMate;

public partial class PaymentDialog : Form
{
    public string Method { get; private set; } = "";
    public string Reference { get; private set; } = "";
    readonly decimal amount;

    public PaymentDialog(decimal amount)
    {
        InitializeComponent();
        this.amount = amount;
        lblAmount.Text = $"Amount due: ₱{amount:N2}\n(fare + refundable deposit)";
        cboMethod.Items.AddRange(SimulatedGateway.Methods);
        cboMethod.SelectedIndex = 0;
    }

    private void cboMethod_SelectedIndexChanged(object? sender, EventArgs e) =>
        lblAccount.Text = cboMethod.Text.StartsWith("Credit") ? "Card number" : $"{cboMethod.Text} mobile no.";

    private void btnPay_Click(object? sender, EventArgs e)
    {
        var r = Pay.Gateway.Charge(cboMethod.Text, txtAccount.Text, amount);
        if (!r.ok) { Ui.Info(r.message); return; }
        Method = cboMethod.Text; Reference = r.reference;
        DialogResult = DialogResult.OK;
    }
}
