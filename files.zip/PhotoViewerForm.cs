namespace DriveMate;

public partial class PhotoViewerForm : Form
{
    public PhotoViewerForm(Booking b)
    {
        InitializeComponent();
        Text = $"Inspection photos – {b.CarName}";
        AddStage("Pickup photos", b.Pickup);
        AddStage("Return photos", b.Return);
    }

    void AddStage(string title, Inspection? insp)
    {
        var header = new Label
        {
            Text = title, Font = new Font("Segoe UI", 11F, FontStyle.Bold), AutoSize = false,
            Width = 700, Height = 30, Margin = new Padding(0, 10, 0, 4)
        };
        flowPhotos.Controls.Add(header);
        flowPhotos.SetFlowBreak(header, true);

        var photos = insp == null ? new List<PhotoItem>() : Database.GetPhotos(insp.Id);
        if (photos.Count == 0)
        {
            var none = new Label { Text = insp == null ? "Not recorded yet." : "No photos attached.", AutoSize = true, ForeColor = Color.DimGray };
            flowPhotos.Controls.Add(none); flowPhotos.SetFlowBreak(none, true);
            return;
        }
        foreach (var p in photos)
        {
            try
            {
                using var ms = new MemoryStream(p.Data);
                using var img = Image.FromStream(ms);
                flowPhotos.Controls.Add(new PictureBox
                {
                    Image = new Bitmap(img), SizeMode = PictureBoxSizeMode.Zoom, Size = new Size(220, 165),
                    BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(0, 0, 10, 10)
                });
            }
            catch { /* skip unreadable image */ }
        }
        flowPhotos.SetFlowBreak(flowPhotos.Controls[^1], true);
    }
}
